const textInput = document.getElementById('textInput');
const fontStylesOutput = document.getElementById('fontStylesOutput');
const fontSizesOutput = document.getElementById('fontSizesOutput');
const copyFontStylesBtn = document.getElementById('copyFontStyles');
const copyFontSizesBtn = document.getElementById('copyFontSizes');

textInput.addEventListener('input', () => {
    const text = textInput.value;
    
    // Reset previous output
    fontStylesOutput.innerHTML = '';
    fontSizesOutput.innerHTML = '';

    // Generate font style options
    const fontStyles = [
        'Arial', 'Times New Roman', 'Verdana', 'Courier New',
        'Georgia', 'Tahoma', 'Palatino', 'Comic Sans MS',
        'Impact', 'Lucida Console', 'Trebuchet MS', 'Century Gothic',
        'Bookman', 'Garamond', 'Copperplate', 'Brush Script MT',
        'Arial Black', 'Franklin Gothic Medium', 'Consolas',
        'Calibri', 'Candara', 'Optima', 'Perpetua', 'Rockwell', 'Segoe UI'
    ];
    const fontStyleHTML = fontStyles.map(style => `<p style="font-family: ${style};">${text}</p>`).join('');
    fontStylesOutput.innerHTML = `<h3>Font Styles</h3>${fontStyleHTML}`;

    // Generate font size options
    const fontSizes = [];
    for (let i = 8; i <= 40; i += 2) {
        fontSizes.push(i);
    }
    const fontSizeHTML = fontSizes.map(size => `<p style="font-size: ${size}px;">${text}</p>`).join('');
    fontSizesOutput.innerHTML = `<h3>Font Sizes</h3>${fontSizeHTML}`;
});

// Copy button functionality
copyFontStylesBtn.addEventListener('click', () => {
    copyToClipboard(fontStylesOutput.innerText);
});

copyFontSizesBtn.addEventListener('click', () => {
    copyToClipboard(fontSizesOutput.innerText);
});

function copyToClipboard(text) {
    const tempInput = document.createElement('textarea');
    tempInput.value = text;
    document.body.appendChild(tempInput);
    tempInput.select();
    document.execCommand('copy');
    document.body.removeChild(tempInput);
    alert('Copied to clipboard!');
}
